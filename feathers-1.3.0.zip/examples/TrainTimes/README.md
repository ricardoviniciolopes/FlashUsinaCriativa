# Train Times Example for Feathers

This [Feathers](http://feathersui.com/) example mocks up a simple application to view train schedules. It uses custom item renderers and a custom theme.

## Web Demo

View the [Train Times example](http://feathersui.com/examples/train-times/) in your browser.