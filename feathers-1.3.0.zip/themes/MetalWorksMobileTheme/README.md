# Metal Works Mobile Theme for Feathers

This [Feathers](http://feathersui.com/) theme combines has an industrial aesthetic with bright orange highlights.

## Credits

Created exclusively for Feathers by [Josh Tynjala](http://twitter.com/joshtynjala). Uses the open source font [Source Sans Pro](https://github.com/adobe/Source-Sans-Pro) created by Adobe Systems Incorporated.

## Preview

The Metal Works Mobile Theme is used in the [Feathers Components Explorer](http://feathersui.com/examples/components-explorer/) example.